

# Fastfetch do Hypr Besita
alias ftb='/usr/bin/fastfetch --config "$HOME/.config/hypr-besita/fastfetch/config.jsonc"'
