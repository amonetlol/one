#!/usr/bin/env bash
set -euo pipefail
systemctl --user import-environment WAYLAND_DISPLAY XDG_RUNTIME_DIR HYPRLAND_INSTANCE_SIGNATURE XDG_CURRENT_DESKTOP HYPR_KAROL_SESSION STARSHIP_CONFIG
"$HOME/.config/themes/apply-theme.sh" gtktheme-Hypr-Karol
pkill -x hyprpaper >/dev/null 2>&1 || true
# Restaura o ultimo wallpaper salvo pelo seletor awww.
if ! /usr/bin/awww query >/dev/null 2>&1; then
    setsid /usr/bin/awww-daemon > "${XDG_RUNTIME_DIR:?}/hypr-karol-awww.log" 2>&1 < /dev/null &
fi
awww_ready=false
for attempt in {1..50}; do
    if /usr/bin/awww query >/dev/null 2>&1; then
        awww_ready=true
        break
    fi
    sleep 0.1
done
if [[ "$awww_ready" == true ]]; then
    /usr/bin/awww restore || printf '%s\n' 'Nao foi possivel restaurar o wallpaper pelo awww.' >&2
else
    printf '%s\n' 'O awww-daemon nao iniciou; confira hypr-karol-awww.log.' >&2
fi
systemctl --user restart elephant.service
sleep 1
"$HOME/.config/hypr_karol/scripts/quickshell-reload.sh" karol
systemctl --user start quickshell-icon-theme.service
