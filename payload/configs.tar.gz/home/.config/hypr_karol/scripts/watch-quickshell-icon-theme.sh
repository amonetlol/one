#!/usr/bin/env bash
set -euo pipefail
config="${1:-karol}"

karol_session_active() {
    local pid
    while IFS= read -r pid; do
        [[ -r "/proc/$pid/cmdline" ]] || continue
        if tr '\0' '\n' < "/proc/$pid/cmdline" | grep -Fxq "$HOME/.config/hypr_karol/hyprland.lua"; then
            return 0
        fi
    done < <(pgrep -u "$UID" -x Hyprland || true)
    return 1
}
while true; do
    gsettings monitor org.gnome.desktop.interface icon-theme | while IFS= read -r _; do
        if karol_session_active; then
            "$HOME/.config/hypr_karol/scripts/quickshell-reload.sh" "$config" --restart
        fi
    done || true
    sleep 1
done
