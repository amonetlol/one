pragma Singleton
pragma ComponentBehavior: Bound

import Quickshell
import Quickshell.Io

Singleton {
    id: root

    property bool enabled: false

    Process {
        command: ["hyprsunset", "--temperature", "4500"]
        running: root.enabled

        onExited: exitCode => {
            if (!root.enabled) return
            console.warn("hyprsunset encerrou inesperadamente:", exitCode)
            root.enabled = false
        }
    }
}
