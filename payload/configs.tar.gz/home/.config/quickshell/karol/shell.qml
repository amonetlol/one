import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland

import qs.state
import qs.features.lockscreen
import qs.features.screenshot
import qs.features.panels.launcher

ShellRoot {
    id: root

    function toggleWallpaper(): void {
        if (Shell.current?.panel === "launcher" && Launcher.text.startsWith(">wallpaper")) {
            Shell.closePanel()
            return
        }
        Shell.openPanel("launcher")
        Qt.callLater(() => Launcher.setText(">wallpaper "))
    }

    Component.onCompleted: Quickshell.watchFiles = !Quickshell.env("INVOCATION_ID")

    GlobalShortcut {
        name: "launcher"
        description: "Open application launcher"
        onPressed: Shell.togglePanel("launcher")
    }

    GlobalShortcut {
        name: "dashboard"
        description: "Toggle the dashboard"
        onPressed: Shell.togglePanel("dashboard")
    }

    GlobalShortcut {
        name: "lock"
        description: "Lock the session"
        onPressed: Shell.lock()
    }

    GlobalShortcut {
        name: "wallpaper"
        description: "Open wallpaper picker"
        onPressed: root.toggleWallpaper()
    }

    GlobalShortcut {
        name: "power"
        description: "Open power controls"
        onPressed: Shell.togglePanel("home")
    }

    IpcHandler {
        target: "shell"

        function togglePanel(name: string): void {
            Shell.togglePanel(name)
        }

        function closePanel(): void {
            Shell.closePanel()
        }

        function lock(): void {
            Shell.lock()
        }
    }

    IpcHandler {
        target: "power"

        function toggle(): void {
            Shell.togglePanel("home")
        }

        function show(): void {
            Shell.openPanel("home")
        }

        function hide(): void {
            if (Shell.current?.panel === "home")
                Shell.closePanel()
        }
    }

    IpcHandler {
        target: "wallpaper"

        function toggle(): void {
            root.toggleWallpaper()
        }

        function show(): void {
            Shell.openPanel("launcher")
            Qt.callLater(() => Launcher.setText(">wallpaper "))
        }
    }

    LockScreen {
        locked: Shell.locked
        onUnlocked: Shell.unlock()
    }

    ScreenshotOverlay {}

    Variants {
        model: Quickshell.screens

        ScreenLayout {
            required property ShellScreen modelData
            screen: modelData
        }
    }
}
