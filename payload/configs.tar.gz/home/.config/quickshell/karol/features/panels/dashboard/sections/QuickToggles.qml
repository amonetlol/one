import QtQuick
import QtQuick.Layouts
import qs.theme
import qs.services
import qs.config
import qs.widgets.buttons

ColumnLayout {
    id: root

    property bool active: false

    property string expandedSection: ""

    onActiveChanged: if (!active) expandedSection = ""

    function toggleSection(name: string): void {
        root.expandedSection = root.expandedSection === name ? "" : name
    }

    spacing: Spacing.spacingSm

    GridLayout {
        Layout.fillWidth: true
        columns: 2 + (Config.showNightToggle ? 1 : 0) + (Config.showDndToggle ? 1 : 0)
        rowSpacing: Spacing.spacingSm
        columnSpacing: Spacing.spacingSm

        ToggleButton {
            Layout.fillWidth: true
            icon: Network.icon
            label: "WiFi"
            isOn: Network.wifiEnabled
            onToggled: Network.toggleWifi()
        }

        ToggleButton {
            Layout.fillWidth: true
            icon: Bluetooth.icon
            label: "Bluetooth"
            isOn: Bluetooth.enabled
            onToggled: Bluetooth.togglePower()
        }

        ToggleButton {
            Layout.fillWidth: true
            visible: Config.showNightToggle
            icon: "moon"
            label: "Night"
            isOn: NightLight.enabled
            onToggled: NightLight.enabled = !NightLight.enabled
        }

        ToggleButton {
            Layout.fillWidth: true
            visible: Config.showDndToggle
            icon: "bell-slash"
            label: "DND"
            isOn: Notifs.dndEnabled
            onToggled: Notifs.toggleDnd()
        }
    }

    NetworkDetail {
        Layout.fillWidth: true
        expanded: root.active && root.expandedSection === "wifi"
        onToggled: root.toggleSection("wifi")
    }

    BluetoothDetail {
        Layout.fillWidth: true
        expanded: root.active && root.expandedSection === "bluetooth"
        onToggled: root.toggleSection("bluetooth")
    }
}
