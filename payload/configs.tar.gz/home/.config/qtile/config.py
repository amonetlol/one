import os
import subprocess
import runpy
runpy.run_path(os.path.expanduser("~/.config/qtile/env.py"))
from libqtile import hook, layout
from libqtile.config import Group, Key, Screen
from libqtile.lazy import lazy
home = os.path.expanduser("~")
rofi = f"{home}/.config/qtile/rofi"
polybar = f"{home}/.config/qtile/polybar"
theme_apply = f"{home}/.config/themes/apply-theme.sh gtktheme-Qtile"
blue, surface = "#8caaee", "#414559"
keys = []
for mod in ("mod1", "mod4"):
    keys.extend([
        Key([mod], "w", lazy.spawn("firefox"), desc="Firefox"),
        Key([mod], "e", lazy.spawn("thunar"), desc="File manager"),
        Key([mod], "Return", lazy.spawn("alacritty"), desc="Terminal"),
        Key([mod], "x", lazy.spawn(f"{rofi}/power.sh"), desc="Power menu"),
        Key([mod], "m", lazy.spawn(f"{home}/.local/bin/mon --qtile"), desc="Monitor mode"),
        Key([mod], "d", lazy.spawn(f"rofi -show drun -config {rofi}/config.rasi"), desc="Rofi launcher"),
    ])
keys.append(Key(["mod4"], "q", lazy.window.kill(), desc="Close window"))
keys.append(Key(["mod4"], "h", lazy.spawn(["alacritty", "-e", "nvim", f"{home}/.config/qtile"]), desc="Edit Qtile config"))
keys.append(Key(["mod4"], "f", lazy.next_layout(), desc="Toggle maximize layout"))
keys.append(Key(["mod4", "shift"], "f", lazy.window.toggle_fullscreen(), desc="Toggle fullscreen"))
keys.append(Key(["mod4", "shift"], "r", lazy.reload_config(), lazy.spawn(f"{polybar}/launch.sh"), desc="Reload Qtile and Polybar"))
keys.extend([Key(["mod4"], "Tab", lazy.spawn(f"{rofi}/alt-tab.sh")), Key(["mod4", "shift"], "q", lazy.shutdown())])
groups = [Group(str(i)) for i in range(1, 6)]
for group in groups:
    keys.extend([Key(["mod4"], group.name, lazy.group[group.name].toscreen()), Key(["mod4", "shift"], group.name, lazy.window.togroup(group.name))])
layouts = [layout.MonadTall(border_width=2, border_focus=blue, border_normal=surface, margin=8), layout.Max()]
screens = [Screen()]
mouse = []
@hook.subscribe.startup_once
def start_desktop():
    os.environ.update({"XDG_CURRENT_DESKTOP": "Qtile", "XDG_SESSION_DESKTOP": "qtile", "XDG_SESSION_TYPE": "x11"})
    os.environ.pop("WAYLAND_DISPLAY", None)
    os.system("systemctl --user unset-environment WAYLAND_DISPLAY")
    os.system("systemctl --user set-environment XDG_CURRENT_DESKTOP=Qtile XDG_SESSION_DESKTOP=qtile XDG_SESSION_TYPE=x11")
    os.system("systemctl --user import-environment DISPLAY XAUTHORITY")
    os.system(f"{polybar}/launch.sh >/tmp/qtile-polybar.log 2>&1 &")
    os.system(f"{theme_apply} >/tmp/qtile-theme.log 2>&1")
    wallpaper_log = os.path.join(os.environ.get("XDG_RUNTIME_DIR", "/tmp"), "qtile-random-wallpaper.log")
    with open(wallpaper_log, "a") as log:
        subprocess.Popen(
            [f"{home}/.config/qtile/random-wallpaper", str(os.getpid())],
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
        )
