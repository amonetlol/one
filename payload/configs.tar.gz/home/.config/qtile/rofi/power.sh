#!/bin/bash
exec rofi -icon-theme "YAMIS" -show power -modi "power:$HOME/.config/qtile/rofi/power-menu.sh" -theme "$HOME/.config/qtile/rofi/power-buttons.rasi"
