#!/usr/bin/env bash
set -euo pipefail
main_list() { printf 'Log out\0icon\x1fsystem-log-out\nRestart\0icon\x1fsystem-reboot\nShutdown\0icon\x1fsystem-shutdown\nSuspend\0icon\x1fsystem-suspend\n'; }
if [[ -z "${1:-}" ]]; then main_list; exit 0; fi
case "$1" in
  "Log out") qtile cmd-obj -o root -f shutdown ;;
  "Restart") printf '\0message\x1fRestart now?\nCancel\0icon\x1fwindow-close\nYes, restart\0icon\x1fsystem-reboot\n' ;;
  "Yes, restart") systemctl reboot ;;
  "Shutdown") printf '\0message\x1fShut down now?\nCancel\0icon\x1fwindow-close\nYes, shut down\0icon\x1fsystem-shutdown\n' ;;
  "Yes, shut down") systemctl poweroff ;;
  "Suspend") systemctl suspend ;;
  "Cancel") main_list ;;
esac
