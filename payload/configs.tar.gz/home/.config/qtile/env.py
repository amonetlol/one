# Ambiente exclusivo dos aplicativos iniciados pela sessao Qtile/X11.
import os

os.environ.update({
    "XDG_CURRENT_DESKTOP": "Qtile",
    "XDG_SESSION_DESKTOP": "qtile",
    "XDG_SESSION_TYPE": "x11",
    "GDK_BACKEND": "x11",
    "QT_QPA_PLATFORM": "xcb",
    "CLUTTER_BACKEND": "x11",
    "MOZ_ENABLE_WAYLAND": "0",
    "SDL_VIDEODRIVER": "x11",
    "MESA_SHADER_CACHE_DISABLE": "false",
    # Menor espera por VSync nos apps Mesa; pode produzir tearing.
    "vblank_mode": "0",
})

for name in ("WAYLAND_DISPLAY", "HYPRLAND_INSTANCE_SIGNATURE", "SWAYSOCK"):
    os.environ.pop(name, None)
