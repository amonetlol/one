# Hypr Kana
Configuracoes do rice: Hyprland, Kitty, Waybar, Dunst, Rofi e perfis Starship neste diretorio.
Bash usa ~/.bashrc. Firefox, yay, Thunar e audio usam suas configuracoes globais.
Icones e fontes: ~/.local/share/icons e ~/.local/share/fonts. Temas: ~/.themes.
Perfil GTK: ~/.config/themes/gtktheme-Hypr-Kana, pelo apply-theme.sh compartilhado.
Cache: ~/.cache. Estado do rice: ~/.local/state/hypr-kana.
Iniciar em TTY: ~/.config/hypr-kana/scripts/session.
