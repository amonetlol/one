-- Kanagawa Dragon do Alpine, adaptado ao Hyprland 0.56 do one.
local root = os.getenv("HOME") .. "/.config/hypr-kana"
dofile(root .. "/monitors.lua")
hl.env("GTK_THEME", "Kanagawa-Yellow-Dark-Dragon")
hl.env("XCURSOR_THEME", "Adwaita")
hl.env("XCURSOR_SIZE", "24")
hl.env("MOZ_ENABLE_WAYLAND", "1")
hl.env("QT_QPA_PLATFORM", "wayland;xcb")
hl.env("QT_STYLE_OVERRIDE", "Adwaita-Dark")
hl.env("XWAYLAND_NO_GLAMOR", "1")
hl.env("QT_QUICK_BACKEND", "software")
hl.env("PATH", root .. "/scripts:" .. os.getenv("HOME") .. "/.local/bin:" .. os.getenv("PATH"))
hl.permission(".*grim.*", "screencopy", "allow")
hl.config({
 input = { kb_layout = "br", kb_variant = "abnt2", follow_mouse = 1, sensitivity = 0 },
 general = { layout = "scrolling", gaps_in = 2, gaps_out = 10, border_size = 0,
   col = { active_border = "rgb(c4b28a)", inactive_border = "rgb(393836)" }, resize_on_border = true, allow_tearing = false },
 scrolling = { column_width = 0.5, explicit_column_widths = "0.333, 0.5, 0.667, 1.0", follow_focus = true },
 decoration = { rounding = 10, active_opacity = 0.90, inactive_opacity = 0.85, fullscreen_opacity = 1.0,
   blur = { enabled = true, size = 3, passes = 2 },
   shadow = { enabled = true, range = 15, render_power = 5, color = "rgba(0d0c0c80)" } },
 animations = { enabled = true },
 misc = { disable_hyprland_logo = true, disable_splash_rendering = true, force_default_wallpaper = -1,
   mouse_move_enables_dpms = true, key_press_enables_dpms = true },
 cursor = { no_hardware_cursors = true },
 xwayland = { force_zero_scaling = true },
 ecosystem = { enforce_permissions = true },
})
hl.curve("fluid", { type = "bezier", points = { {0.15, 0.85}, {0.25, 1} } })
hl.animation({ leaf = "windows", enabled = true, speed = 3, bezier = "fluid", style = "popin 5%" })
hl.animation({ leaf = "fade", enabled = true, speed = 4, bezier = "fluid" })
hl.animation({ leaf = "workspaces", enabled = true, speed = 2, bezier = "fluid", style = "slide" })
dofile(root .. "/binds.lua")
hl.on("hyprland.start", function() hl.exec_cmd(root .. "/scripts/session-start") end)

-- HyprExpo: plugin e configuracoes locais desta sessao.
dofile(os.getenv("HOME") .. "/.config/hypr-kana/overview.lua")
