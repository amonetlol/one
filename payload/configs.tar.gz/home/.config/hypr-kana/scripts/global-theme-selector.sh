#!/bin/bash
exec "$HOME/.config/hypr-kana/scripts/standard/settings"
