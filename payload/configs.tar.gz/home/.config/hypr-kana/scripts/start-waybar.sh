#!/usr/bin/env bash
root="$HOME/.config/hypr-kana"
source "$root/scripts/environment"
mkdir -p "$HOME/.local/state/hypr-kana"
echo $$ > "$HOME/.local/state/hypr-kana/waybar.pid"
exec waybar -c "$root/waybar/config.jsonc" -s "$root/waybar/style.css" "$@"
