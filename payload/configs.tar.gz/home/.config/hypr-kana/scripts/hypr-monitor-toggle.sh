#!/bin/sh
exec "$HOME/.config/hypr-kana/scripts/mon" "$@"
