#!/bin/bash
set -euo pipefail
wallpaper_dir="$HOME/Imagens/wallpapers"
[[ -d "$wallpaper_dir" ]] || exit 0
mapfile -d '' files < <(find "$wallpaper_dir" -type f \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o -iname '*.webp' \) -print0)
(( ${#files[@]} )) || exit 0
image="${files[RANDOM % ${#files[@]}]}"
exec "$HOME/.config/hypr-kana/scripts/swww-all.sh" "$image"
