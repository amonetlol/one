#!/bin/bash
exec "$HOME/.bin/random-wallpaper.sh"
