#!/bin/bash
set -euo pipefail
image="${1:-}"
[[ -f "$image" ]] || exit 1
if ! awww query >/dev/null 2>&1; then
    awww-daemon >/dev/null 2>&1 </dev/null &
    for i in {1..50}; do awww query >/dev/null 2>&1 && break; sleep .1; done
fi
awww img "$image"
mkdir -p "$HOME/.local/state/hypr-kana"
printf '%s\n' "$image" > "$HOME/.local/state/hypr-kana/wallpaper"
