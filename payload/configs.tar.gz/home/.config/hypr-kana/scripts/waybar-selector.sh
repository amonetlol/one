#!/bin/bash
notify-send "Waybar" "Estilo ativo: elifouts default"
exec "$HOME/.config/hypr-kana/scripts/standard/waybar-restart"
