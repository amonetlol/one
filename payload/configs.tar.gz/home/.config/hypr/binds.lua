-- Padrao compartilhado com Pie/Besita: scrolling e atalhos amonetlol.
hl.config({
    general = { layout = "scrolling" },
    scrolling = { column_width = 0.5, explicit_column_widths = "0.333, 0.5, 0.667, 1.0", follow_focus = true },
})
-- Prioridade: amonetlol/ps binds-niri.txt; complemento: binds.txt.
-- Layout scrolling: largura, centralizacao e troca de colunas equivalentes ao Niri.
local root = os.getenv("HOME") .. "/.config/hypr"
local function run(key, command) hl.bind(key, hl.dsp.exec_cmd(command)) end
local function script(key, name, args) run(key, root .. "/scripts/standard/" .. name .. (args and (" " .. args) or "")) end
for _, mod in ipairs({ "SUPER", "ALT" }) do
    script(mod .. " + RETURN", "terminal")
    run(mod .. " + W", "firefox")
    run(mod .. " + E", "thunar")
    script(mod .. " + D", "launcher")
    run(mod .. " + M", "$HOME/.local/bin/mon")
    script(mod .. " + X", "power-menu")
    script(mod .. " + H", "settings")
    script(mod .. " + F10", "wallpaper")
    hl.bind(mod .. " + Q", hl.dsp.window.close())
end
script("SUPER + F1", "show-hotkeys")
script("SUPER + period", "settings")
run("CTRL + SHIFT + R", "hyprctl reload")
run("SUPER + SHIFT + R", "hyprctl reload")
script("SUPER + F12", "waybar-restart")
script("SUPER + ALT + T", "terminal", "-e btop")
script("ALT + C", "clipboard")
script("SUPER + SHIFT + L", "lock")
hl.bind("CTRL + ALT + Delete", hl.dsp.exit())
hl.bind("SUPER + SHIFT + P", hl.dsp.dpms({ action = "off" }))
hl.bind("SUPER + T", hl.dsp.window.float({ action = "toggle" }))
hl.bind("SUPER + F", hl.dsp.window.fullscreen({ mode = "maximized", action = "toggle" }))
hl.bind("SUPER + SHIFT + F", hl.dsp.window.fullscreen({ mode = "fullscreen", action = "toggle" }))
hl.bind("SUPER + minus", hl.dsp.layout("colresize -0.1"))
hl.bind("SUPER + equal", hl.dsp.layout("colresize +0.1"))
hl.bind("SUPER + BackSpace", hl.dsp.layout("colresize -conf"))
hl.bind("SUPER + C", hl.dsp.layout("center"))
-- Hyprland sem plugin de overview: seletor de janelas com Rofi.
script("SUPER + SHIFT + D", "windows")
for _, direction in ipairs({ "left", "right", "up", "down" }) do
    hl.bind("SUPER + " .. direction, hl.dsp.focus({ direction = direction }))
end
hl.bind("SUPER + SHIFT + left", hl.dsp.layout("swapcol l"))
hl.bind("SUPER + SHIFT + right", hl.dsp.layout("swapcol r"))
for i = 1, 10 do
    local key = i % 10
    hl.bind("SUPER + " .. key, hl.dsp.focus({ workspace = i }))
    hl.bind("SUPER + SHIFT + " .. key, hl.dsp.window.move({ workspace = i }))
end
script("Print", "screenshot", "area")
script("CTRL + Print", "screenshot", "screen")
script("ALT + Print", "screenshot", "window")


-- Navegacao e atalhos exclusivos preservados quando nao ha conflito.
hl.bind("ALT + Tab", hl.dsp.window.cycle_next())
hl.bind("ALT + SHIFT + Tab", hl.dsp.window.cycle_next({ next = false }))
hl.bind("SUPER + SHIFT + up", hl.dsp.window.swap({ direction = "up" }))
hl.bind("SUPER + SHIFT + down", hl.dsp.window.swap({ direction = "down" }))
hl.bind("SUPER + V", hl.dsp.window.float({ action = "toggle" }))
hl.bind("SUPER + P", hl.dsp.window.pseudo())
hl.bind("SUPER + SHIFT + E", hl.dsp.exit())
script("SUPER + SHIFT + X", "power-menu")
run("SUPER + B", "brave")
run("SUPER + R", root .. "/scripts/random-wall.sh")
run("SUPER + SHIFT + W", root .. "/scripts/waybar-selector.sh")
run("SUPER + SHIFT + T", root .. "/scripts/global-theme-selector.sh")
run("SUPER + SHIFT + M", root .. "/scripts/hypr-monitor-toggle.sh")
for _, item in ipairs({ {"J", "down"}, {"K", "up"}, {"L", "right"} }) do
    hl.bind("SUPER + " .. item[1], hl.dsp.focus({ direction = item[2] }))
end
hl.bind("SUPER + mouse_down", hl.dsp.focus({ workspace = "e+1" }))
hl.bind("SUPER + mouse_up", hl.dsp.focus({ workspace = "e-1" }))
hl.bind("SUPER + mouse:272", hl.dsp.window.drag(), { mouse = true })
hl.bind("SUPER + mouse:273", hl.dsp.window.resize(), { mouse = true })
hl.bind("XF86AudioRaiseVolume", hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%+"), { repeating = true, locked = true })
hl.bind("XF86AudioLowerVolume", hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"), { repeating = true, locked = true })
hl.bind("XF86AudioMute", hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"), { locked = true })
hl.bind("XF86MonBrightnessUp", hl.dsp.exec_cmd("brightnessctl s 5%+"), { repeating = true, locked = true })
hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd("brightnessctl s 5%-"), { repeating = true, locked = true })
script("SUPER + Print", "screenshot", "screen")

--[==[
//---- DESATIVADOS ----
Registro dos binds originais. Os atalhos exclusivos compativeis foram preservados acima.
Conflitos: Super+H, Super+T, Super+J (togglesplit) e Super+Setas.
-- ── Keybinds ─────────────────────────────────
local mod = "SUPER"
local mon = shell_quote(HOME .. "/.local/bin/mon") .. " --hypr"
--local logout = shell_quote(SCRIPTS_DIR .. "Wlogout.sh")
local logout = shell_quote(WAYBAR_DIR .. "/scripts/power-menu.sh")

local function bind_apps(modifier)
	hl.bind(modifier .. " + W", hl.dsp.exec_cmd("firefox"))
	hl.bind(modifier .. " + E", hl.dsp.exec_cmd(file))
	hl.bind(modifier .. " + Return", hl.dsp.exec_cmd(terminal))
	hl.bind(modifier .. " + X", hl.dsp.exec_cmd(logout))
	hl.bind(modifier .. " + M", hl.dsp.exec_cmd(mon))
	hl.bind(modifier .. " + D", hl.dsp.exec_cmd(menu))
end

bind_apps("SUPER")
bind_apps("ALT")

-- Default programs
-- App binds are grouped below for Super and Alt.
-- Rofi is included in the shared app binds below.
hl.bind(mod .. " + SHIFT + X", hl.dsp.exec_cmd(shell_quote(WAYBAR_DIR .. "scripts/power-menu.sh")))
hl.bind(mod .. " + Q", hl.dsp.window.close()) -- was killactive (graceful close)
hl.bind(mod .. " + SHIFT + E", hl.dsp.exit())
hl.bind(mod .. " + F", hl.dsp.window.fullscreen()) -- was fullscreen, 0
hl.bind(mod .. " + V", hl.dsp.window.float({ action = "toggle" })) -- togglefloating
hl.bind(mod .. " + P", hl.dsp.window.pseudo()) -- pseudo
hl.bind(mod .. " + J", hl.dsp.layout("togglesplit")) -- togglesplit (layoutmsg)
hl.bind(mod .. " + B", hl.dsp.exec_cmd(browser))
-- Thunar is included in the shared app binds below.
--hl.bind(mod .. " + C", hl.dsp.exec_cmd("libreoffice --writer"))
hl.bind(mod .. " + T", hl.dsp.exec_cmd(shell_quote(SCRIPTS_DIR .. "wall-selector.sh")))
hl.bind(mod .. " + R", hl.dsp.exec_cmd(shell_quote(SCRIPTS_DIR .. "random-wall.sh")))
hl.bind(mod .. " + SHIFT + W", hl.dsp.exec_cmd(shell_quote(SCRIPTS_DIR .. "waybar-selector.sh")))
hl.bind(mod .. " + SHIFT + T", hl.dsp.exec_cmd(shell_quote(SCRIPTS_DIR .. "global-theme-selector.sh")))
hl.bind(mod .. " + SHIFT + M", hl.dsp.exec_cmd(shell_quote(SCRIPTS_DIR .. "hypr-monitor-toggle.sh")))

-- Move focus (Vim-style)
hl.bind(mod .. " + H", hl.dsp.focus({ direction = "left" }))
hl.bind(mod .. " + L", hl.dsp.focus({ direction = "right" }))
hl.bind(mod .. " + K", hl.dsp.focus({ direction = "up" }))
hl.bind(mod .. " + J", hl.dsp.focus({ direction = "down" }))

-- Resize windows (Arrow keys) — binde → { repeating = true }
hl.bind(mod .. " + left", hl.dsp.window.resize({ x = -20, y = 0, relative = true }), { repeating = true })
hl.bind(mod .. " + right", hl.dsp.window.resize({ x = 20, y = 0, relative = true }), { repeating = true })
hl.bind(mod .. " + up", hl.dsp.window.resize({ x = 0, y = -20, relative = true }), { repeating = true })
hl.bind(mod .. " + down", hl.dsp.window.resize({ x = 0, y = 20, relative = true }), { repeating = true })

-- Switch workspaces (was 9 explicit binds — loop is idiomatic Lua, same effect)
for i = 1, 9 do
	hl.bind(mod .. " + " .. i, hl.dsp.focus({ workspace = i }))
end

-- Move active window to workspace
for i = 1, 9 do
	hl.bind(mod .. " + SHIFT + " .. i, hl.dsp.window.move({ workspace = i }))
end

-- Scroll through workspaces (mouse wheel)
hl.bind(mod .. " + mouse_down", hl.dsp.focus({ workspace = "e+1" }))
hl.bind(mod .. " + mouse_up", hl.dsp.focus({ workspace = "e-1" }))

-- Move/resize windows with mouse (was bindm)
hl.bind(mod .. " + mouse:272", hl.dsp.window.drag(), { mouse = true })
hl.bind(mod .. " + mouse:273", hl.dsp.window.resize(), { mouse = true })

-- Volume & brightness (media keys) — bindel/bindl → { repeating, locked }
hl.bind(
	"XF86AudioRaiseVolume",
	hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%+"),
	{ repeating = true, locked = true }
)
hl.bind(
	"XF86AudioLowerVolume",
	hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"),
	{ repeating = true, locked = true }
)
hl.bind("XF86AudioMute", hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"), { locked = true })
hl.bind("XF86MonBrightnessUp", hl.dsp.exec_cmd("brightnessctl s 5%+"), { repeating = true, locked = true })
hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd("brightnessctl s 5%-"), { repeating = true, locked = true })

-- Screenshot (requires grim + slurp)
hl.bind("Print", hl.dsp.exec_cmd('grim -g "$(slurp)" - | wl-copy'))
hl.bind(mod .. " + Print", hl.dsp.exec_cmd("grim - | wl-copy"))


]==]
