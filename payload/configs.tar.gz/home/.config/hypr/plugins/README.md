# HyprExpo — hypr
Binario, patch e configuracao copiados do Hypr Vora do one.
Origem: https://github.com/sandwichfarm/hyprexpo
Commit: 5891014c611e1bd56d0121143f0221d46b5c0967
Hyprland: efb50993780079460b0cbed1363e2166a2de1d9f (0.56.2).
Super+Tab: abrir/fechar. Setas: navegar. Enter: selecionar. Esc: cancelar.
Permissao restrita ao plugin nesta pasta. Ativar na proxima entrada na sessao.
Nao descarregar/recarregar o plugin em uso; veja capture-fix-status.txt.
Recompilar para os headers correspondentes apos atualizar o Hyprland.

Correcao de navegacao: navigation-fix-status.txt e navigation-fix.patch.
