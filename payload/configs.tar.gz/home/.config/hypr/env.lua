-- Environment: VMware + São Paulo + Hyprland session (hypr4)

local home = os.getenv("HOME") or "/home/rice"
local rt = os.getenv("XDG_RUNTIME_DIR") or "/run/user/1000"

hl.env("TZ", "America/Sao_Paulo")
hl.env("EDITOR", "nvim")
hl.env("CLUTTER_BACKEND", "wayland")
hl.env("XDG_CURRENT_DESKTOP", "Hyprland")
hl.env("XDG_SESSION_DESKTOP", "Hyprland")
hl.env("DESKTOP_SESSION", "Hyprland")
hl.env("XDG_SESSION_TYPE", "wayland")
hl.env("MOZ_ENABLE_WAYLAND", "1")
hl.env("ELECTRON_OZONE_PLATFORM_HINT", "auto")
hl.env("SSH_AUTH_SOCK", rt .. "/keyring/ssh")

hl.env("FOOTINI", home .. "/.config/hypr/foot/foot.ini")



hl.env("QT_AUTO_SCREEN_SCALE_FACTOR", "1")
hl.env("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1")
hl.env("QT_QPA_PLATFORMTHEME", "qt6ct")
hl.env("GDK_SCALE", "1")
hl.env("QT_SCALE_FACTOR", "1")

-- Compatibilidade do Hypr Pie adaptada para a sessao Hypr.
hl.env("LANG", "pt_BR.UTF-8")
hl.env("LANGUAGE", "pt_BR:pt")
hl.env("QT_QUICK_BACKEND", "software")
hl.env("GDK_BACKEND", "wayland,x11,*")
hl.env("QT_QPA_PLATFORM", "wayland;xcb")
hl.env("XCURSOR_SIZE", "24")
hl.env("XCURSOR_THEME", "Bibata-Modern-Ice")
hl.env("HYPRCURSOR_SIZE", "24")
hl.env("HYPRCURSOR_THEME", "Bibata-Modern-Ice")

-- Recursos proprios desta configuracao.
hl.env("STARSHIP_CONFIG", home .. "/.config/hypr/starship-lightblue.toml")
local session_path = os.getenv("PATH") or "/usr/bin"
for _, entry in ipairs({ home .. "/.local/bin", home .. "/.config/hypr/scripts" }) do
    if not (":" .. session_path .. ":"):find(":" .. entry .. ":", 1, true) then
        session_path = entry .. ":" .. session_path
    end
end
hl.env("PATH", session_path)

-- Opcao efetiva de cursor usada pelo Pie no Hyprland atual.
hl.config({ cursor = { no_hardware_cursors = true } })

-- VMware: start XWayland without Glamor, matching the Vora profile.
hl.env("XWAYLAND_NO_GLAMOR", "1")
