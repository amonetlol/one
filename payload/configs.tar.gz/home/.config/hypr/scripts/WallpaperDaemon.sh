#!/usr/bin/env bash
set -euo pipefail

command -v awww-daemon >/dev/null 2>&1 || { echo "awww-daemon nao encontrado" >&2; exit 1; }
command -v awww >/dev/null 2>&1 || { echo "awww nao encontrado" >&2; exit 1; }

if ! awww query >/dev/null 2>&1; then
  nohup awww-daemon >/tmp/hypr-awww-daemon.log 2>&1 </dev/null &
  ready=0
  for _ in {1..100}; do
    if awww query >/dev/null 2>&1; then ready=1; break; fi
    sleep 0.1
  done
  if [[ "$ready" -ne 1 ]]; then
    echo "awww-daemon nao ficou pronto; veja /tmp/hypr-awww-daemon.log" >&2
    exit 1
  fi
fi

exec "$HOME/.bin/random-wallpaper.sh"
