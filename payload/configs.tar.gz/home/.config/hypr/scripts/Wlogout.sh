#!/usr/bin/env bash
exec "$HOME/.local/bin/wlogout" --hypr_conf
