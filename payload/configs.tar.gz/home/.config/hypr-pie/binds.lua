-- Prioridade: amonetlol/ps binds-niri.txt; complemento: binds.txt.
-- Aplicativos adaptados a partir da preferência de binds-niri.
local root = os.getenv("HOME") .. "/.config/hypr-pie"
local function run(key, command) hl.bind(key, hl.dsp.exec_cmd(command)) end
run("SUPER + RETURN", "$HOME/.config/hypr-pie/scripts/foot")
run("SUPER + W", "firefox")
run("SUPER + E", "thunar")
run("SUPER + D", "$HOME/.config/hypr-pie/scripts/launcher")
run("SUPER + M", "$HOME/.local/bin/mon")
run("SUPER + X", "$HOME/.config/hypr-pie/scripts/power")
run("SUPER + H", "$HOME/.config/hypr-pie/scripts/settings")
run("SUPER + F10", "$HOME/.config/hypr-pie/scripts/wallpaper")
hl.bind("SUPER + Q", hl.dsp.window.close())
run("ALT + RETURN", "$HOME/.config/hypr-pie/scripts/foot")
run("ALT + W", "firefox")
run("ALT + E", "thunar")
run("ALT + D", "$HOME/.config/hypr-pie/scripts/launcher")
run("ALT + M", "$HOME/.local/bin/mon")
run("ALT + X", "$HOME/.config/hypr-pie/scripts/power")
run("ALT + H", "$HOME/.config/hypr-pie/scripts/settings")
run("ALT + F10", "$HOME/.config/hypr-pie/scripts/wallpaper")
hl.bind("ALT + Q", hl.dsp.window.close())
run("ALT + C", "$HOME/.config/hypr-pie/scripts/clipboard")
run("SUPER + F1", "$HOME/.config/hypr-pie/scripts/show-hotkeys")
run("SUPER + period", "$HOME/.config/hypr-pie/scripts/settings")
run("CTRL + SHIFT + R", "hyprctl reload")
run("SUPER + SHIFT + R", "hyprctl reload")
run("SUPER + F12", "$HOME/.config/hypr-pie/scripts/waybar-restart")
run("SUPER + ALT + T", "$HOME/.config/hypr-pie/scripts/terminal -e btop")
run("SUPER + SHIFT + L", "$HOME/.config/hypr-pie/scripts/lock")
hl.bind("CTRL + ALT + Delete", hl.dsp.exit())
hl.bind("SUPER + SHIFT + P", hl.dsp.dpms({ action = "off" }))
hl.bind("SUPER + T", hl.dsp.window.float({ action = "toggle" }))
hl.bind("SUPER + F", hl.dsp.window.fullscreen({ mode = "maximized", action = "toggle" }))
hl.bind("SUPER + SHIFT + F", hl.dsp.window.fullscreen({ mode = "fullscreen", action = "toggle" }))
hl.bind("SUPER + minus", hl.dsp.layout("colresize -0.1"))
hl.bind("SUPER + equal", hl.dsp.layout("colresize +0.1"))
hl.bind("SUPER + BackSpace", hl.dsp.layout("colresize -conf"))
hl.bind("SUPER + C", hl.dsp.layout("center"))
run("SUPER + SHIFT + D", "$HOME/.config/hypr-pie/scripts/windows")
hl.bind("SUPER + left", hl.dsp.focus({ direction = "left" }))
hl.bind("SUPER + SHIFT + left", hl.dsp.layout("swapcol l"))
hl.bind("SUPER + right", hl.dsp.focus({ direction = "right" }))
hl.bind("SUPER + SHIFT + right", hl.dsp.layout("swapcol r"))
hl.bind("SUPER + up", hl.dsp.focus({ direction = "up" }))
hl.bind("SUPER + SHIFT + up", hl.dsp.window.swap({ direction = "up" }))
hl.bind("SUPER + down", hl.dsp.focus({ direction = "down" }))
hl.bind("SUPER + SHIFT + down", hl.dsp.window.swap({ direction = "down" }))
hl.bind("SUPER + 1", hl.dsp.focus({ workspace = 1 }))
hl.bind("SUPER + SHIFT + 1", hl.dsp.window.move({ workspace = 1 }))
hl.bind("SUPER + 2", hl.dsp.focus({ workspace = 2 }))
hl.bind("SUPER + SHIFT + 2", hl.dsp.window.move({ workspace = 2 }))
hl.bind("SUPER + 3", hl.dsp.focus({ workspace = 3 }))
hl.bind("SUPER + SHIFT + 3", hl.dsp.window.move({ workspace = 3 }))
hl.bind("SUPER + 4", hl.dsp.focus({ workspace = 4 }))
hl.bind("SUPER + SHIFT + 4", hl.dsp.window.move({ workspace = 4 }))
hl.bind("SUPER + 5", hl.dsp.focus({ workspace = 5 }))
hl.bind("SUPER + SHIFT + 5", hl.dsp.window.move({ workspace = 5 }))
hl.bind("SUPER + 6", hl.dsp.focus({ workspace = 6 }))
hl.bind("SUPER + SHIFT + 6", hl.dsp.window.move({ workspace = 6 }))
hl.bind("SUPER + 7", hl.dsp.focus({ workspace = 7 }))
hl.bind("SUPER + SHIFT + 7", hl.dsp.window.move({ workspace = 7 }))
hl.bind("SUPER + 8", hl.dsp.focus({ workspace = 8 }))
hl.bind("SUPER + SHIFT + 8", hl.dsp.window.move({ workspace = 8 }))
hl.bind("SUPER + 9", hl.dsp.focus({ workspace = 9 }))
hl.bind("SUPER + SHIFT + 9", hl.dsp.window.move({ workspace = 9 }))
hl.bind("SUPER + 0", hl.dsp.focus({ workspace = 10 }))
hl.bind("SUPER + SHIFT + 0", hl.dsp.window.move({ workspace = 10 }))
run("Print", "$HOME/.config/hypr-pie/scripts/screenshot area")
run("CTRL + Print", "$HOME/.config/hypr-pie/scripts/screenshot screen")
run("ALT + Print", "$HOME/.config/hypr-pie/scripts/screenshot window")

-- Exclusivos do rice original, adaptados para os caminhos do Hypr Pie.
run("SUPER + SHIFT + RETURN", "$HOME/.config/hypr-pie/scripts/terminal --title floatingTerminal")
hl.bind("SUPER + grave", hl.dsp.workspace.toggle_special("scratch"))
hl.bind("SUPER + SHIFT + grave", hl.dsp.window.move({ workspace = "special:scratch" }))
run("SUPER + B", "firefox")
run("SUPER + SPACE", "$HOME/.config/hypr-pie/scripts/launcher")
hl.bind("SUPER + L", hl.dsp.focus({ direction = "right" }))
hl.bind("SUPER + K", hl.dsp.focus({ direction = "up" }))
hl.bind("SUPER + J", hl.dsp.focus({ direction = "down" }))
hl.bind("SUPER + SHIFT + H", hl.dsp.window.swap({ direction = "left" }))
hl.bind("SUPER + SHIFT + J", hl.dsp.window.swap({ direction = "down" }))
hl.bind("SUPER + SHIFT + K", hl.dsp.window.swap({ direction = "up" }))
hl.bind("SUPER + SHIFT + code:20", hl.dsp.window.resize({ x = 0, y = -15, relative = true }), { repeating = true })
hl.bind("SUPER + SHIFT + code:21", hl.dsp.window.resize({ x = 0, y = 15, relative = true }), { repeating = true })
hl.bind("SUPER + mouse:272", hl.dsp.window.drag(), { mouse = true })
hl.bind("SUPER + mouse:273", hl.dsp.window.resize(), { mouse = true })
hl.bind("SUPER + SHIFT + M", hl.dsp.window.fullscreen({ mode = "fullscreen", action = "toggle" }))
run("SUPER + SHIFT + S", "$HOME/.config/hypr-pie/scripts/screenshot area")
run("SUPER + SHIFT + O", "$HOME/.config/hypr-pie/scripts/upstream/screenocr_select.sh")
run("SUPER + Escape", "$HOME/.config/hypr-pie/scripts/lock")
hl.bind("XF86AudioPlay", hl.dsp.exec_cmd("playerctl play-pause"), { locked = true })
hl.bind("XF86AudioNext", hl.dsp.exec_cmd("playerctl next"), { locked = true })
hl.bind("XF86AudioPrev", hl.dsp.exec_cmd("playerctl previous"), { locked = true })
hl.bind("XF86AudioRaiseVolume", hl.dsp.exec_cmd("$HOME/.config/hypr-pie/scripts/upstream/volume.sh up"), { locked = true, repeating = true })
hl.bind("XF86AudioLowerVolume", hl.dsp.exec_cmd("$HOME/.config/hypr-pie/scripts/upstream/volume.sh down"), { locked = true, repeating = true })
hl.bind("XF86AudioMute", hl.dsp.exec_cmd("$HOME/.config/hypr-pie/scripts/upstream/volume.sh mute"), { locked = true })
hl.bind("XF86AudioMicMute", hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle"), { locked = true })
hl.bind("XF86MonBrightnessUp", hl.dsp.exec_cmd("$HOME/.config/hypr-pie/scripts/upstream/brightness.sh up"), { locked = true, repeating = true })
hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd("$HOME/.config/hypr-pie/scripts/upstream/brightness.sh down"), { locked = true, repeating = true })
hl.bind("CTRL + XF86MonBrightnessUp", hl.dsp.exec_cmd("brightnessctl --device='*kbd_backlight*' set +5%"))
hl.bind("CTRL + XF86MonBrightnessDown", hl.dsp.exec_cmd("brightnessctl --device='*kbd_backlight*' set 5%-"))

--[[
//---- DESATIVADOS ----
Registro integral dos binds originais de michal-pielka/dotfiles, antes da adaptação.
Os exclusivos compatíveis foram reativados acima com caminhos do Hypr Pie.
Os conflitos de teclas/ações abaixo permanecem comentados:
- Super+F: floating original substituído por maximizar; floating usa Super+T.
- Super+X: togglesplit/dwindle substituído pelo menu de energia; layout é scrolling.
- Super+H: foco à esquerda substituído pelas configurações.
- Super+M: maximizar substituído pelo controle de monitores.
- Super+W: alternar Waybar substituído por Firefox; Super+F12 reinicia Waybar.
- Super+Tab: workspace anterior substituído por seletor de janelas (overview equivalente).
- Super+Shift+L: swap e mover janela flutuante substituídos pelo bloqueio.
- Super+Shift+R: gravação substituída por reload.
- Super+code:20/21: resize original substituído pelos controles de largura minus/equal.
- Mover janelas flutuantes em Shift+H/J/K conflita com swap original; swap é preservado.
- Super+T e switch de tampa Apple são específicos de hardware Apple e não são usados.
- Return, Q e números são definidos uma única vez pelos padrões amonetlol.

local vars = require("modules.vars")
local mainMod = vars.mainMod
local terminal = vars.terminal
local browser = vars.browser
local menu = vars.menu

hl.bind(mainMod .. " + Return", hl.dsp.exec_cmd(terminal))
hl.bind(mainMod .. " + SHIFT + Return", hl.dsp.exec_cmd(terminal .. " --title floatingTerminal"))
hl.bind(mainMod .. " + grave", hl.dsp.workspace.toggle_special("scratch"))
hl.bind(mainMod .. " + SHIFT + grave", hl.dsp.window.move({ workspace = "special:scratch" }))
hl.bind(mainMod .. " + B", hl.dsp.exec_cmd(browser))
hl.bind(mainMod .. " + SPACE", hl.dsp.exec_cmd(menu))

hl.bind(mainMod .. " + Q", hl.dsp.window.close())
hl.bind(mainMod .. " + F", hl.dsp.window.float({ action = "toggle" }))
hl.bind(mainMod .. " + X", hl.dsp.layout("togglesplit")) -- dwindle

-- Move focus with mainMod + h/j/k/l
hl.bind(mainMod .. " + H", hl.dsp.focus({ direction = "left" }))
hl.bind(mainMod .. " + L", hl.dsp.focus({ direction = "right" }))
hl.bind(mainMod .. " + K", hl.dsp.focus({ direction = "up" }))
hl.bind(mainMod .. " + J", hl.dsp.focus({ direction = "down" }))

-- Swap windows with mainMod + SHIFT + h/j/k/l
-- TODO(investigate): This is a conflict with moveactive binds below
hl.bind(mainMod .. " + SHIFT + h", hl.dsp.window.swap({ direction = "left" }))
hl.bind(mainMod .. " + SHIFT + j", hl.dsp.window.swap({ direction = "down" }))
hl.bind(mainMod .. " + SHIFT + k", hl.dsp.window.swap({ direction = "up" }))
hl.bind(mainMod .. " + SHIFT + l", hl.dsp.window.swap({ direction = "right" }))

-- Move floating windows with mainMod + SHIFT + h/j/k/l
hl.bind(mainMod .. " + SHIFT + h", hl.dsp.window.move({ x = -15, y = 0, relative = true }), { repeating = true })
hl.bind(mainMod .. " + SHIFT + j", hl.dsp.window.move({ x = 0, y = 15, relative = true }), { repeating = true })
hl.bind(mainMod .. " + SHIFT + k", hl.dsp.window.move({ x = 0, y = -15, relative = true }), { repeating = true })
hl.bind(mainMod .. " + SHIFT + l", hl.dsp.window.move({ x = 15, y = 0, relative = true }), { repeating = true })

-- Switch workspaces with mainMod + [0-9]
-- Move active window to a workspace with mainMod + SHIFT + [0-9]
for i = 1, 10 do
	local key = i % 10 -- 10 maps to key 0
	hl.bind(mainMod .. " + " .. key, hl.dsp.focus({ workspace = i }))
	hl.bind(mainMod .. " + SHIFT + " .. key, hl.dsp.window.move({ workspace = i }))
end

-- Tab between last and current workspace
hl.bind(mainMod .. " + Tab", hl.dsp.focus({ workspace = "previous" }))

-- Resize active window
hl.bind(mainMod .. " + code:20", hl.dsp.window.resize({ x = -15, y = 0, relative = true }), { repeating = true })
hl.bind(mainMod .. " + code:21", hl.dsp.window.resize({ x = 15, y = 0, relative = true }), { repeating = true })
hl.bind(mainMod .. " + SHIFT + code:20", hl.dsp.window.resize({ x = 0, y = -15, relative = true }), { repeating = true })
hl.bind(mainMod .. " + SHIFT + code:21", hl.dsp.window.resize({ x = 0, y = 15, relative = true }), { repeating = true })

-- Move/resize windows with mainMod + LMB/RMB and dragging
hl.bind(mainMod .. " + mouse:272", hl.dsp.window.drag(), { mouse = true })
hl.bind(mainMod .. " + mouse:273", hl.dsp.window.resize(), { mouse = true })

-- Maximize / Fullscreen
hl.bind(mainMod .. " + M", hl.dsp.window.fullscreen({ mode = "maximized" }))
hl.bind(mainMod .. " + SHIFT + M", hl.dsp.window.fullscreen({ mode = "fullscreen" }))

-- Media Control
hl.bind("XF86AudioPlay", hl.dsp.exec_cmd("playerctl play-pause"), { locked = true })
hl.bind("XF86AudioNext", hl.dsp.exec_cmd("playerctl next"), { locked = true })
hl.bind("XF86AudioPrev", hl.dsp.exec_cmd("playerctl previous"), { locked = true })

-- Volume Control
hl.bind("XF86AudioRaiseVolume", hl.dsp.exec_cmd("~/.dotfiles/scripts/volume.sh up"), { locked = true, repeating = true })
hl.bind("XF86AudioLowerVolume", hl.dsp.exec_cmd("~/.dotfiles/scripts/volume.sh down"),
	{ locked = true, repeating = true })
hl.bind("XF86AudioMute", hl.dsp.exec_cmd("~/.dotfiles/scripts/volume.sh mute"), { locked = true })

-- Screen Brightness Control
hl.bind("XF86MonBrightnessUp", hl.dsp.exec_cmd("~/.dotfiles/scripts/brightness.sh up"),
	{ locked = true, repeating = true })
hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd("~/.dotfiles/scripts/brightness.sh down"),
	{ locked = true, repeating = true })

-- Keyboard Brightness Control
hl.bind("CTRL + XF86MonBrightnessUp", hl.dsp.exec_cmd("brightnessctl --device='*kbd_backlight*' set +5%"))
hl.bind("CTRL + XF86MonBrightnessDown", hl.dsp.exec_cmd("brightnessctl --device='*kbd_backlight*' set 5%-"))

-- Toggle touchpad
local trackpadEnabled = true
hl.bind(mainMod .. " + T", function()
    trackpadEnabled = not trackpadEnabled
    hl.device({ name = "apple-spi-trackpad", enabled = trackpadEnabled })
end)

-- Screenshot - save to clipboard
hl.bind(mainMod .. " + SHIFT + S", hl.dsp.exec_cmd("~/.dotfiles/scripts/screenshot_select.sh"))

-- Screen record - save to clipboard
hl.bind(mainMod .. " + SHIFT + R", hl.dsp.exec_cmd("~/.dotfiles/scripts/screenrecord_select.sh"))

-- Screen OCR - copy text from selected screen area to clipboard
hl.bind(mainMod .. " + SHIFT + O", hl.dsp.exec_cmd("~/.dotfiles/scripts/screenocr_select.sh"))

-- Lock screen
hl.bind(mainMod .. " + Escape", hl.dsp.exec_cmd("pidof hyprlock || hyprlock"))

-- Lock on lid close
hl.bind("switch:on:Apple SMC power/lid events", hl.dsp.exec_cmd("pidof hyprlock || hyprlock"), { locked = true })

-- Toggle waybar
hl.bind(mainMod .. " + w", hl.dsp.exec_cmd("killall -SIGUSR1 waybar"))

]]
