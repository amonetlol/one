Hypr Pie
========
Origem: https://github.com/michal-pielka/dotfiles (MIT; LICENSE.upstream)
Binds: https://github.com/amonetlol/ps/blob/main/binds-niri.txt
Complemento: https://github.com/amonetlol/ps/blob/main/binds.txt

Sess?o SDDM: Hypr Pie. N?o altera a sess?o padr?o nem encerra a sess?o atual.
Config: ~/.config/hypr-pie/hyprland.lua
Apps e Starship: todos dentro de ~/.config/hypr-pie.
Tema: ~/.config/themes/gtktheme-Hypr-Pie; GTK3: ~/.themes/Hypr-Pie.
Usa o aplicador de temas existente ao iniciar a sess?o.
Bash: STARSHIP_CONFIG ? selecionado somente com HYPR_PIE_SESSION=1.

Prefer?ncia Niri: Alacritty, Nautilus, layout scrolling e binds de coluna.
Foot tamb?m configurado: ~/.config/hypr-pie/scripts/foot.
Super+Tab usa seletor de janelas Rofi, equivalente aproximado ao overview.
Super+C centraliza; Alt+C abre clipboard. Super+F1 mostra BINDS.txt.
Originais comentados no final de binds.lua sob //---- DESATIVADOS ----.
Wallpapers: ~/Imagens/wallpapers e imagens originais em hypr-pie/wallpapers.
Swaybg, swaylock e swayidle aproveitam os pacotes j? instalados.
GTK4/libadwaita pode usar as pr?prias cores; o perfil solicita modo escuro.

PACOTES (inspe??o em 2026-10-23; nenhum pacote instalado por esta tarefa)
Essenciais instalados: hyprland, sddm, rofi, foot, alacritty, fastfetch,
waybar, wlogout, starship, ttf-jetbrains-mono-nerd, pipewire,
pipewire-pulse, wireplumber, libnotify, polkit-kde-agent.
Essencial ausente: mako. Configura??o pronta; notifica??es do rice dependem dele.
Binds instalados: firefox, nautilus, neovim, btop, grim, slurp,
wl-clipboard, cliphist, swappy, playerctl, brightnessctl, jq, python,
swaybg, swaylock, swayidle, tesseract (OCR adaptado para ingl?s).
Opcionais ausentes: xdg-desktop-portal-hyprland (compartilhamento de tela),
wf-recorder (grava??o; bind original conflita com reload e fica comentado),
hyprpaper/hyprlock/hypridle (substitutos das alternativas sway instaladas).
Fuzzel, yazi, keyd e ferramentas de desenvolvimento do instalador original
n?o s?o necess?rios ao escopo. Foot padr?o dispensa o fork foot-vim.
Decis?o do usu?rio: n?o instalar pacotes por enquanto.

Valida??o: Hyprland --verify-config, luac -p, foot -C,
bash -n, parsers JSON/JSONC/TOML, sintaxe Python e desktop-file-validate.
Sem valida??o visual ou de funcionamento em sess?o gr?fica.
