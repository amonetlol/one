-- Hypr Pie: michal-pielka/dotfiles + preferências amonetlol.
local root = os.getenv("HOME") .. "/.config/hypr-pie"
hl.monitor({ output = "Virtual-1", mode = "1920x1080@60", position = "0x0", scale = 1 })
hl.env("LANG", "pt_BR.UTF-8")
hl.env("LANGUAGE", "pt_BR:pt")
hl.env("QT_QUICK_BACKEND", "software")
-- VMware: compatibility for Kitty and other XWayland apps.
hl.env("XWAYLAND_NO_GLAMOR", "1")
hl.env("XCURSOR_SIZE", "24")
hl.env("XCURSOR_THEME", "Bibata-Modern-Ice")
hl.env("GDK_BACKEND", "wayland,x11,*")
hl.env("QT_QPA_PLATFORM", "wayland;xcb")
hl.env("STARSHIP_CONFIG", root .. "/starship-pie.toml")
hl.env("PATH", root .. "/scripts:" .. os.getenv("HOME") .. "/.local/bin:" .. os.getenv("PATH"))
hl.permission(".*grim.*", "screencopy", "allow")
hl.config({
    general = { layout = "scrolling", resize_on_border = true },
    scrolling = { column_width = 0.5, explicit_column_widths = "0.333, 0.5, 0.667, 1.0", follow_focus = true },
    input = { kb_layout = "br", kb_variant = "abnt2", follow_mouse = 1, touchpad = { natural_scroll = true } },
    cursor = { no_hardware_cursors = true },
    misc = { mouse_move_enables_dpms = true, key_press_enables_dpms = true },
    ecosystem = { enforce_permissions = true },
})
dofile(root .. "/modules/look.lua")
dofile(root .. "/modules/animations.lua")
dofile(root .. "/modules/rules.lua")
dofile(root .. "/binds.lua")
hl.on("hyprland.start", function() hl.exec_cmd(root .. "/scripts/start-services") end)

-- Dedicated Kitty profile (XWayland for VMware).
hl.env("KITTY_CONFIG_DIRECTORY", "/home/pio/.config/hypr-pie/kitty")
hl.env("TERMINAL", "/home/pio/.config/hypr-pie/kitty/launch")

-- HyprExpo: plugin e configuracoes locais desta sessao.
dofile(os.getenv("HOME") .. "/.config/hypr-pie/overview.lua")
