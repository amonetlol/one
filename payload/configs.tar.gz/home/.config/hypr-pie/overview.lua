-- HyprExpo pinned to the compatible build for Hyprland v0.56.2.
local root = os.getenv("HOME") .. "/.config/hypr-pie"
hl.permission(os.getenv("HOME") .. "/[.]config/hypr-pie/plugins/hyprexpo[.]so", "plugin", "allow")
hl.plugin.load(root .. "/plugins/hyprexpo.so")

if hl.plugin.hyprexpo ~= nil then
hl.config({ plugin = { hyprexpo = {
    bg_col = "rgb(11111b)",
    keynav_enable = 1,
    keynav_wrap_h = 1,
    keynav_wrap_v = 1,
    cancel_key = "escape",
    drag_drop_enable = 0,
} } })
end

hl.define_submap("hyprexpo", function()
    hl.bind("left", function() hl.plugin.hyprexpo.kb_focus("left") end)
    hl.bind("right", function() hl.plugin.hyprexpo.kb_focus("right") end)
    hl.bind("up", function() hl.plugin.hyprexpo.kb_focus("up") end)
    hl.bind("down", function() hl.plugin.hyprexpo.kb_focus("down") end)
    hl.bind("return", function() hl.plugin.hyprexpo.kb_confirm() end)
    hl.bind("escape", function() hl.plugin.hyprexpo.expo("cancel") end)
    hl.bind("SUPER + Tab", function() hl.plugin.hyprexpo.expo("toggle") end)
end)

-- Atalho global, alem do mesmo atalho dentro do overview.
hl.bind("SUPER + Tab", function()
    if hl.plugin.hyprexpo ~= nil then hl.plugin.hyprexpo.expo("toggle") end
end)
