# Hypr Vora
Fonte: https://github.com/AbiturabVora/dotfiles-sway-ab
Binds prioritários: https://github.com/amonetlol/ps/blob/main/binds-niri.txt
Demais padrões: https://github.com/amonetlol/ps/blob/main/binds.txt

Sessão SDDM: Hypr Vora. Configuração: hyprland.lua e binds.lua.
Componentes isolados: rofi, foot, fastfetch, waybar, wlogout e sddm.
O diretório sddm é somente uma cópia para consulta/prévia; não é ativado.
Perfil GTK: ~/.config/themes/gtktheme-Hypr-Vora, carregado na entrada da sessão.
Starship: ~/.config/starship-vora.toml; export comentado no .bashrc e ativo nesta sessão.
Fastfetch: alias ftv carrega a configuração Vora; fastfetch e os demais atalhos mantêm suas próprias opções.
Super+Tab abre um seletor Rofi de janelas, pois o overview do Niri não é nativo do Hyprland.
Dependências: Hyprland (Lua e scrolling), foot, rofi, fastfetch, waybar, wlogout,
swayidle, swaylock, swaybg, wl-clipboard, cliphist, grim, slurp, swappy, jq,
btop, neovim, firefox, thunar, brightnessctl, playerctl, pavucontrol,
network-manager-applet, blueman, JetBrainsMono Nerd Font, Bibata-Modern-Ice.
Nenhum instalador upstream foi executado.
