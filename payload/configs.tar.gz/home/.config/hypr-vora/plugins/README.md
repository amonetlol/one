# HyprExpo Vora
Source: https://github.com/sandwichfarm/hyprexpo
Commit: 5891014c611e1bd56d0121143f0221d46b5c0967
Built against Hyprland efb50993780079460b0cbed1363e2166a2de1d9f (v0.56.2) and installed headers.
Loaded by ../overview.lua. Rebuild for the matching headers after changing Hyprland.
The scoped permission requires leaving and entering Hypr Vora once after installation.
Super+Tab: toggle overview. Arrows: navigate. Enter: select. Escape: cancel.
Ctrl+Tab: Rofi window selector.

Vora customization: vora-grid3.patch wraps previews at three windows per row and reveals/focuses the selected window.

Correcao de navegacao: navigation-fix-status.txt e navigation-fix.patch.
