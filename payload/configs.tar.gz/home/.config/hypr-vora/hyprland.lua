-- Hypr Vora: adapted from AbiturabVora/dotfiles-sway-ab.
local root = os.getenv("HOME") .. "/.config/hypr-vora"
hl.env("GTK_THEME", "Colloid-Dark-Catppuccin")
hl.monitor({ output = "Virtual-1", mode = "1920x1080@60", position = "0x0", scale = 1 })
hl.env("QT_QUICK_BACKEND", "software")
-- Compatibilidade X11 na VM: evita falhas do Glamor no Wayland.
hl.env("XWAYLAND_NO_GLAMOR", "1")
hl.env("XCURSOR_SIZE", "24")
hl.env("HYPRCURSOR_SIZE", "24")
hl.env("XCURSOR_THEME", "Bibata-Modern-Ice")
hl.env("GDK_BACKEND", "wayland,x11,*")
hl.env("QT_QPA_PLATFORM", "wayland;xcb")
hl.env("STARSHIP_CONFIG", os.getenv("HOME") .. "/.config/starship-vora.toml")
hl.permission(".*grim.*", "screencopy", "allow")
hl.config({
	ecosystem = {
		enforce_permissions = true,
	},
})

hl.config({
	general = {
		gaps_in = 4,
		gaps_out = 4,
		border_size = 2,
		col = {
			active_border = { colors = { "rgb(dce4f5)", "rgb(74c7ec)" }, angle = 45 },
			inactive_border = "rgba(8c8fa1aa)",
		},
		layout = "scrolling",
		resize_on_border = false,
		allow_tearing = false,
	},

	decoration = {
		rounding = 8,
		rounding_power = 2,
		active_opacity = 1.0,
		inactive_opacity = 1.0,
		shadow = {
			enabled = true,
			range = 20,
			render_power = 3,
			color = "rgba(00000055)",
		},
		blur = {
			enabled = true,
			size = 8,
			passes = 2,
			ignore_opacity = false,
			vibrancy = 0.12,
		},
	},

	animations = {
		enabled = true,
	},

	misc = {
		disable_hyprland_logo = true,
		focus_on_activate = true,
	},

	input = {
		kb_layout = "br",
		kb_variant = "abnt2",
		follow_mouse = 1,
		sensitivity = 0,
		touchpad = {
			natural_scroll = true,
			disable_while_typing = false,
			tap_to_click = true,
			clickfinger_behavior = true,
		},
	},

	cursor = {
		no_hardware_cursors = true,
		hide_on_key_press = true,
	},
})


hl.config({ scrolling = { column_width = 0.5, explicit_column_widths = "0.333, 0.5, 0.667, 1.0", follow_focus = true }, misc = { mouse_move_enables_dpms = true, key_press_enables_dpms = true } })
hl.on("hyprland.start", function()
    hl.exec_cmd(root .. "/scripts/start-services")
end)
dofile(root .. "/overview.lua")
dofile(root .. "/binds.lua")

-- Dedicated Kitty profile (XWayland for VMware).
hl.env("KITTY_CONFIG_DIRECTORY", "/home/pio/.config/hypr-vora/kitty")
hl.env("TERMINAL", "/home/pio/.config/hypr-vora/kitty/launch")
