#!/usr/bin/env bash
exec rofi -config "$HOME/.config/hypr-besita/rofi/config.rasi" -show drun "$@"
