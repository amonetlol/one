#!/usr/bin/env bash
set -euo pipefail
choice=$(cliphist list | rofi -config "$HOME/.config/hypr-besita/rofi/config.rasi" -dmenu -p Clipboard) || exit 0
[[ -n "$choice" ]] || exit 0
printf '%s\n' "$choice" | cliphist decode | wl-copy
