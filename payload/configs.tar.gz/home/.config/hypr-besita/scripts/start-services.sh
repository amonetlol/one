#!/usr/bin/env bash
set -u
root="$HOME/.config/hypr-besita"
export STARSHIP_CONFIG="$root/starship-besita.toml"
logdir="${XDG_RUNTIME_DIR:?}/hypr-besita"
mkdir -p "$logdir"
systemctl --user import-environment WAYLAND_DISPLAY XDG_RUNTIME_DIR HYPRLAND_INSTANCE_SIGNATURE XDG_CURRENT_DESKTOP HYPR_BESITA_SESSION STARSHIP_CONFIG
"$HOME/.config/themes/apply-theme.sh" gtktheme-Hypr-Besita
hyprctl setcursor Bibata-Modern-Ice 24
"$root/scripts/waybar-restart.sh"
dunst -conf "$root/dunst/dunstrc" > "$logdir/dunst.log" 2>&1 &
wl-paste --type text --watch cliphist store &
wl-paste --type image --watch cliphist store &
if [[ -s "$root/wallpaper-path" ]]; then
    swaybg -i "$(cat "$root/wallpaper-path")" -m fill > "$logdir/wallpaper.log" 2>&1 &
else
    swaybg -c '#212020' > "$logdir/wallpaper.log" 2>&1 &
fi
echo $! > "$XDG_RUNTIME_DIR/hypr-besita-wallpaper.pid"
if ! pgrep -u "$(id -u)" -f '^/usr/lib/polkit-kde-authentication-agent-1' >/dev/null; then
    /usr/lib/polkit-kde-authentication-agent-1 &
fi
