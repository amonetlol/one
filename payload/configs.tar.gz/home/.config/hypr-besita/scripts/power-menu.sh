#!/usr/bin/env bash
exec /usr/bin/wlogout -l "$HOME/.config/hypr-besita/wlogout/layout" -C "$HOME/.config/hypr-besita/wlogout/style.css" -b 5
