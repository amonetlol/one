#!/usr/bin/env bash
set -euo pipefail
mode="${1:-area}"
mkdir -p "$HOME/Imagens/Screenshots"
file="$HOME/Imagens/Screenshots/$(date +%Y%m%d-%H%M%S).png"
case "$mode" in
 area|save|edit) geometry=$(slurp) || exit 0; grim -g "$geometry" "$file" ;;
 screen) grim "$file" ;;
 window) geometry=$(hyprctl -j activewindow | jq -r '"\(.at[0]),\(.at[1]) \(.size[0])x\(.size[1])"'); [[ "$geometry" != *null* ]] || exit 0; grim -g "$geometry" "$file" ;;
 *) exit 2 ;;
esac
wl-copy --type image/png < "$file"
[[ "$mode" != edit ]] || swappy -f "$file"
