#!/usr/bin/env bash
set -euo pipefail
/usr/bin/swaylock -f -C "$HOME/.config/hypr-besita/swaylock.conf"
[[ ${1:-} != suspend ]] || /usr/bin/systemctl suspend
