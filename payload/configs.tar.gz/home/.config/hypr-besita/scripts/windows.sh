#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path
root = Path.home()/'.config/hypr-besita'
clients = json.loads(subprocess.check_output(['hyprctl', '-j', 'clients']))
if not clients: raise SystemExit(0)
if len(sys.argv) > 1:
    active = json.loads(subprocess.check_output(['hyprctl', '-j', 'activewindow']))
    clients = [c for c in clients if c['workspace']['id'] == active.get('workspace', {}).get('id')]
    if not clients: raise SystemExit(0)
    index = next((i for i, c in enumerate(clients) if c['address'] == active.get('address')), -1)
    address = clients[(index + (-1 if sys.argv[1] == 'prev' else 1)) % len(clients)]['address']
else:
    rows = [f"[{c['workspace']['id']}] {c['class']} — {c['title']}".replace('\n', ' ') for c in clients]
    p = subprocess.run(['rofi', '-config', str(root/'rofi/config.rasi'), '-dmenu', '-p', 'Janelas', '-format', 'i', '-no-custom'], input='\n'.join(rows), text=True, stdout=subprocess.PIPE)
    if p.returncode or not p.stdout.strip(): raise SystemExit(0)
    address = clients[int(p.stdout)]['address']
subprocess.run(['hyprctl', 'eval', 'hl.dispatch(hl.dsp.focus({ window = '+json.dumps('address:'+address)+' }))'], check=True)
