#!/usr/bin/env bash
set -euo pipefail
root="$HOME/.config/hypr-besita"
exec "$root/scripts/terminal.sh" --working-directory "$root" -e nvim "$root"
