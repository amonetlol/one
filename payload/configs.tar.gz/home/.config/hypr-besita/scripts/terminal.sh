#!/usr/bin/env bash
exec "/home/pio/.config/hypr-besita/kitty/launch" "$@"
