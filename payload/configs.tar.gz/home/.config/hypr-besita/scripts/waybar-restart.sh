#!/usr/bin/env bash
set -euo pipefail
root="$HOME/.config/hypr-besita"
state="${XDG_RUNTIME_DIR:?}/hypr-besita-waybar.pid"
if [[ -r "$state" ]]; then
    read -r pid < "$state"
    if [[ "$pid" =~ ^[0-9]+$ ]] && [[ "$(readlink "/proc/$pid/exe" 2>/dev/null || true)" == /usr/bin/waybar ]]; then
        if tr '\0' ' ' < "/proc/$pid/cmdline" | grep -Fq '/hypr-besita/waybar/'; then kill "$pid"; fi
    fi
fi
/usr/bin/waybar -c "$root/waybar/config.jsonc" -s "$root/waybar/style.css" > "${XDG_RUNTIME_DIR}/hypr-besita-waybar.log" 2>&1 &
echo $! > "$state"
