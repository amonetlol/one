#!/usr/bin/env bash
set -euo pipefail
root="$HOME/.config/hypr-besita"
rofi -config "$root/rofi/config.rasi" -dmenu -i -p 'Atalhos Besita' < "$root/BINDS.txt" > /dev/null || true
