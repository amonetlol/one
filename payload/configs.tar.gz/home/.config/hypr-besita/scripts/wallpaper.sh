#!/usr/bin/env python3
from pathlib import Path
import os, subprocess
root = Path.home()/'.config/hypr-besita'
folder = Path.home()/'Imagens/wallpapers'
images = sorted(p for p in folder.rglob('*') if p.is_file() and p.suffix.lower() in ('.png','.jpg','.jpeg','.webp') and '\n' not in str(p))
images += sorted(p for p in (root/'wallpapers').glob('*') if p.suffix.lower() in ('.png','.jpg','.jpeg','.webp'))
if not images: raise SystemExit('Nenhum wallpaper encontrado em ~/Imagens/wallpapers ou no rice')
# Rofi row icons render each image as a preview; the returned index still selects the original file.
images = [p for p in images if not any(c in str(p) for c in ('\n', '\r', '\x00', '\x1f'))]
rows = [f'{p.name}\0icon\x1f{p}\x1fmeta\x1f{p}' for p in images]
result = subprocess.run(['rofi','-config',str(root/'rofi/config.rasi'),'-theme',str(root/'rofi/wallpaper.rasi'),'-show-icons','-scroll-method','1','-no-cycle','-kb-row-left','Left','-kb-row-right','Right','-kb-move-char-back','Control+b','-kb-move-char-forward','Control+f','-dmenu','-i','-p','Wallpaper','-format','i','-no-custom'], input='\n'.join(rows), text=True, stdout=subprocess.PIPE)
if result.returncode or not result.stdout.strip(): raise SystemExit(0)
image = images[int(result.stdout)]
runtime = Path(os.environ['XDG_RUNTIME_DIR'])
state = runtime/'hypr-besita-wallpaper.pid'
if state.exists():
    try:
        pid = int(state.read_text())
        cmdline = Path(f'/proc/{pid}/cmdline').read_bytes()
        if Path(f'/proc/{pid}/exe').resolve() == Path('/usr/bin/swaybg'):
            os.kill(pid, 15)
    except (OSError, ValueError): pass
with open(runtime/'hypr-besita-wallpaper.log','ab') as log:
    proc = subprocess.Popen(['/usr/bin/swaybg','-i',str(image),'-m','fill'],stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
state.write_text(str(proc.pid)+'\n')
(root/'wallpaper-path').write_text(str(image)+'\n')
