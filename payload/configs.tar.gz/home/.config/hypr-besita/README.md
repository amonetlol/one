# Hypr Besita
Base: https://github.com/2besita/2besita-dots (MangoWM), paleta Echidna.
Kitty: https://github.com/dream-wa1ker/hyprdots-0/tree/main/dots/dot_config/kitty
Binds: https://github.com/amonetlol/ps (binds-niri.txt prioritário).
Selecione **Hypr Besita** no SDDM. Nenhuma sessão existente foi substituída.
O layout scrolling aproxima os comandos Niri. Rofi e Wlogout foram criados na paleta do Foot.
Foot/Alacritty usam JetBrainsMono Nerd Font instalada; Mononoki original é opcional.
Kitty mantém os atalhos e kittens upstream, usa shell da sessão e tema Echidna.
O repositório original não distribui wallpaper nem os scripts privados citados nos binds.
O fundo inicial é sólido #212020. Adicione uma imagem em wallpapers/ e use o seletor.
GTK: ~/.config/themes/gtktheme-Hypr-Besita; tema instalado em ~/.themes/Hypr-Besita.
Alias ftb carrega exclusivamente o fastfetch desta pasta.
