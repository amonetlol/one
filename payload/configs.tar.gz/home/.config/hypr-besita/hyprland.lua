-- Besita / Echidna adapted from 2besita's MangoWM rice.
local root = os.getenv("HOME") .. "/.config/hypr-besita"
hl.monitor({ output = "Virtual-1", mode = "1920x1080@60", position = "0x0", scale = 1 })
hl.env("LANG", "pt_BR.UTF-8")
hl.env("LANGUAGE", "pt_BR:pt")
hl.env("TZ", "America/Sao_Paulo")
hl.env("XCURSOR_THEME", "Bibata-Modern-Ice")
hl.env("XCURSOR_SIZE", "24")
hl.env("GTK_THEME", "Colloid-Green-Dark-Everforest")
hl.env("HYPR_BESITA_SESSION", "1")
hl.env("STARSHIP_CONFIG", root .. "/starship-besita.toml")
hl.env("PATH", root .. "/scripts:" .. os.getenv("HOME") .. "/.local/bin:" .. os.getenv("PATH"))
hl.env("GDK_BACKEND", "wayland,x11,*")
hl.env("QT_QPA_PLATFORM", "wayland;xcb")
hl.env("QT_QUICK_BACKEND", "software")
-- VMware: compatibility for Kitty and other XWayland apps.
hl.env("XWAYLAND_NO_GLAMOR", "1")
hl.permission(".*grim.*", "screencopy", "allow")
hl.config({
    general = { layout = "scrolling", gaps_in = 4, gaps_out = 6, border_size = 1, resize_on_border = true,
        col = { active_border = "rgb(c3d9ac)", inactive_border = "rgb(7c7c70)" } },
    scrolling = { column_width = 0.5, explicit_column_widths = "0.333, 0.5, 0.667, 1.0", follow_focus = true },
    input = { kb_layout = "br", kb_variant = "abnt2", follow_mouse = 1, touchpad = { natural_scroll = true } },
    cursor = { no_hardware_cursors = true },
    decoration = { rounding = 0, active_opacity = 1, inactive_opacity = 1,
        blur = { enabled = true, size = 1, passes = 3 },
        shadow = { enabled = false } },
    misc = { disable_hyprland_logo = true, mouse_move_enables_dpms = true, key_press_enables_dpms = true },
    ecosystem = { enforce_permissions = true },
    animations = { enabled = true },
})
hl.curve("besita", { type = "bezier", points = { {0.16, 1}, {0.3, 1} } })
hl.animation({ leaf = "windowsIn", enabled = true, speed = 6.67, bezier = "besita", style = "popin 70%" })
hl.animation({ leaf = "windowsOut", enabled = true, speed = 8.33, bezier = "besita" })
hl.animation({ leaf = "fadeOut", enabled = true, speed = 8.33, bezier = "besita" })
hl.animation({ leaf = "workspaces", enabled = true, speed = 2.86, bezier = "besita", style = "slide" })
hl.layer_rule({ match = { namespace = "rofi" }, blur = true })
dofile(root .. "/binds.lua")
hl.on("hyprland.start", function() hl.exec_cmd(root .. "/scripts/start-services.sh") end)

-- Dedicated Kitty profile (XWayland for VMware).
hl.env("KITTY_CONFIG_DIRECTORY", "/home/pio/.config/hypr-besita/kitty")
hl.env("TERMINAL", "/home/pio/.config/hypr-besita/kitty/launch")

-- HyprExpo: plugin e configuracoes locais desta sessao.
dofile(os.getenv("HOME") .. "/.config/hypr-besita/overview.lua")
