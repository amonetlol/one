# Pacotes — Hypr Besita na VM one

Inventário somente leitura em 24/10/2026: CachyOS, usuário pio. Nenhum pacote instalado ou removido nesta análise.

## Essenciais para os componentes solicitados

| Pacote/recurso | Uso | Estado |
|---|---|---|
| hyprland | Compositor e sessão Hypr Besita | Instalado 0.56.2 |
| sddm | Entrada de sessão solicitada | Instalado |
| rofi | Launcher Wayland e seletores | Instalado 2.0.0 |
| foot, alacritty, kitty | Três terminais solicitados | Todos instalados |
| fastfetch | Informações do sistema e alias ftb | Instalado |
| waybar | Barra, workspaces Hyprland, CPU, memória e relógio | Instalado 0.15.0 |
| wlogout | Menu de energia | Instalado |
| dunst | Notificações e dunstctl usado pela barra | Instalado |
| ttf-terminus-nerd | Família Terminess Nerd Font Mono da barra/dunst | Instalado |
| bash | Script de estado/toggle dunst | Disponível |
| D-Bus | Comunicação notificações e controles da sessão | Já fornecido pelo ambiente |

Nenhum pacote obrigatório novo para executar os componentes pedidos com as fontes Nerd Font já disponíveis.

## Essenciais para funções adicionais usadas pelos atalhos

| Pacote/recurso | Função | Estado |
|---|---|---|
| awww | Wallpaper, daemon e troca de imagem | Instalado |
| grim, slurp, wl-clipboard | Captura de tela, seleção de região e área de transferência | Instalados |
| cliphist | Histórico da área de transferência | Instalado |
| swaylock | Bloqueio da sessão, alternativa já disponível ao hyprlock | Instalado |
| firefox, thunar, neovim, btop | Aplicativos dos atalhos do usuário | Instalados |
| pipewire-pulse/pactl | Módulo de áudio e alteração de volume na Waybar | Instalados |
| pavucontrol | Clique no módulo de áudio | Instalado |
| jq, python | Auxiliares de adaptação e scripts | Disponíveis |

CPU, memória, relógio e workspaces são módulos internos da Waybar; não precisam de programas de monitoramento adicionais.

## Opcionais para decidir

| Pacote | Motivo | Estado |
|---|---|---|
| **ttf-mononoki-nerd** | Reproduz a fonte original do Foot; pode-se usar JetBrainsMono Nerd Font Mono já instalada sem impedir funcionamento | **Ausente; disponível no repositório extra (2,47 MiB download)** |
| hyprlock | Alternativa ao swaylock existente, sem necessidade para o rice | Ausente |
| noto-fonts-cjk | Caracteres japoneses decorativos da barra original | Já instalado |
| brightnessctl, playerctl | Brilho e mídia, se habilitados os atalhos correspondentes | Já instalados |

Instalação mínima adicional recomendada apenas para fidelidade visual: `ttf-mononoki-nerd`. A decisão permanece com o usuário; não executar instalação automaticamente.

## O que não é necessário importar

- O repositório original é para MangoWM. MangoWM e Fuzzel não são necessários na adaptação para Hyprland/Rofi.
- O repositório não fornece configurações de Rofi ou Wlogout: esses temas precisam ser derivados da paleta existente.
- Fish, Starship, tmux, Neovim personalizado, rmpc, MPD, mpd-discord-rpc, yazi, Emacs e st fazem parte de outros fluxos do autor e não são requisitos deste escopo. Não iniciar os serviços MPD do autostart original.
- Kitty upstream usa `shell fish`; adaptar ao shell atual elimina essa dependência ausente. Os arquivos `search.py` e `scroll_mark.py` usam as bibliotecas internas do Kitty e a biblioteca padrão Python; não exigem instalação via pip.
- Fastfetch original fixa Sixel e métricas Nix; adaptar imagem/protocolo e módulos ao CachyOS. Chafa não é requisito quando a configuração não usa esse backend.
- Scripts em `mango/scripts` citados nos atalhos não foram publicados no repositório. Não tratar referências como arquivos disponíveis ou dependências automaticamente resolvidas.
- swww e hyprpaper não são necessários com awww já instalado. Não há necessidade de instalar um segundo daemon de wallpaper.

## Fontes da análise

- https://github.com/2besita/2besita-dots — revisão `4c5420d61f8714fc10beb34ef853a7b1d363b33a`: README, foot/foot.ini, waybar/*, dunst/dunstrc, mango/autostart.sh e mango/mango/keymaps.conf.
- https://github.com/dream-wa1ker/hyprdots-0/tree/main/dots/dot_config/kitty — revisão `89d452d8347c4bb96a03666337a9897f42b19f33`: kitty.conf, search.py e scroll_mark.py.
- https://github.com/amonetlol/ps/blob/main/binds-niri.txt e binds.txt — aplicativos e funções dos atalhos solicitados.
- VM: `command -v`, `pacman -Q`, `pacman -Si ttf-mononoki-nerd` e `fc-list`. A presença dos binários/fontes foi verificada; funcionamento em sessão gráfica não foi testado.
