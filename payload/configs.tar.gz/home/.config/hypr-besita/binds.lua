-- Prioridade: amonetlol/ps binds-niri.txt; complemento: binds.txt.
-- Layout scrolling: largura, centralizacao e troca de colunas equivalentes ao Niri.
local root = os.getenv("HOME") .. "/.config/hypr-besita"
local function run(key, command) hl.bind(key, hl.dsp.exec_cmd(command)) end
local function script(key, name, args) run(key, root .. "/scripts/" .. name .. ".sh" .. (args and (" " .. args) or "")) end
for _, mod in ipairs({ "SUPER", "ALT" }) do
    script(mod .. " + RETURN", "terminal")
    run(mod .. " + W", "firefox")
    run(mod .. " + E", "thunar")
    script(mod .. " + D", "launcher")
    run(mod .. " + M", "$HOME/.local/bin/mon")
    script(mod .. " + X", "power-menu")
    script(mod .. " + H", "settings")
    script(mod .. " + F10", "wallpaper")
    hl.bind(mod .. " + Q", hl.dsp.window.close())
end
script("SUPER + F1", "show-hotkeys")
script("SUPER + period", "settings")
run("CTRL + SHIFT + R", "hyprctl reload")
run("SUPER + SHIFT + R", "hyprctl reload")
script("SUPER + F12", "waybar-restart")
script("SUPER + ALT + T", "terminal", "-e btop")
script("ALT + C", "clipboard")
script("SUPER + SHIFT + L", "lock")
hl.bind("CTRL + ALT + Delete", hl.dsp.exit())
hl.bind("SUPER + SHIFT + P", hl.dsp.dpms({ action = "off" }))
hl.bind("SUPER + T", hl.dsp.window.float({ action = "toggle" }))
hl.bind("SUPER + F", hl.dsp.window.fullscreen({ mode = "maximized", action = "toggle" }))
hl.bind("SUPER + SHIFT + F", hl.dsp.window.fullscreen({ mode = "fullscreen", action = "toggle" }))
hl.bind("SUPER + minus", hl.dsp.layout("colresize -0.1"))
hl.bind("SUPER + equal", hl.dsp.layout("colresize +0.1"))
hl.bind("SUPER + BackSpace", hl.dsp.layout("colresize -conf"))
hl.bind("SUPER + C", hl.dsp.layout("center"))
-- Hyprland sem plugin de overview: seletor de janelas com Rofi.
script("SUPER + SHIFT + D", "windows")
for _, direction in ipairs({ "left", "right", "up", "down" }) do
    hl.bind("SUPER + " .. direction, hl.dsp.focus({ direction = direction }))
end
hl.bind("SUPER + SHIFT + left", hl.dsp.layout("swapcol l"))
hl.bind("SUPER + SHIFT + right", hl.dsp.layout("swapcol r"))
for i = 1, 10 do
    local key = i % 10
    hl.bind("SUPER + " .. key, hl.dsp.focus({ workspace = i }))
    hl.bind("SUPER + SHIFT + " .. key, hl.dsp.window.move({ workspace = i }))
end
script("Print", "screenshot", "area")
script("CTRL + Print", "screenshot", "screen")
script("ALT + Print", "screenshot", "window")

-- Exclusivos do Mango adaptados para Hyprland.
hl.bind("SUPER + SPACE", hl.dsp.window.float({ action = "toggle" }))
script("SUPER + SHIFT + Tab", "wallpaper")
run("SUPER + B", "firefox")
script("SUPER + A", "terminal", "-e yazi")
run("SUPER + SHIFT + A", "dolphin")
hl.bind("SUPER + L", hl.dsp.focus({ direction = "right" }))
hl.bind("SUPER + K", hl.dsp.focus({ direction = "up" }))
hl.bind("SUPER + J", hl.dsp.focus({ direction = "down" }))
script("ALT + Tab", "windows", "next")
script("ALT + SHIFT + Tab", "windows", "prev")
for _, item in ipairs({ {"H", "left"}, {"L", "right"}, {"K", "up"}, {"J", "down"} }) do
    -- Super+Shift+L pertence ao bloqueio; a troca a direita usa as setas acima.
    if item[1] ~= "L" then hl.bind("SUPER + SHIFT + " .. item[1], hl.dsp.window.swap({ direction = item[2] })) end
end
hl.bind("SUPER + SHIFT + M", hl.dsp.window.fullscreen({ mode = "fullscreen", action = "toggle" }))
script("SUPER + ALT + P", "screenshot", "screen")
script("SUPER + P", "screenshot", "screen")
script("SUPER + CTRL + P", "screenshot", "window")
hl.bind("SUPER + mouse:272", hl.dsp.window.drag(), { mouse = true })
hl.bind("SUPER + mouse:273", hl.dsp.window.resize(), { mouse = true })
for _, item in ipairs({ {"Up", 0, -50}, {"Down", 0, 50}, {"Left", -50, 0}, {"Right", 50, 0}, {"K", 0, -50}, {"J", 0, 50}, {"H", -50, 0}, {"L", 50, 0} }) do
    hl.bind("SUPER + CTRL + SHIFT + " .. item[1], hl.dsp.window.move({ x = item[2], y = item[3], relative = true }))
end
for _, item in ipairs({ {"K", 0, -50}, {"J", 0, 50}, {"H", -50, 0}, {"L", 50, 0} }) do
    hl.bind("CTRL + SUPER + " .. item[1], hl.dsp.window.resize({ x = item[2], y = item[3], relative = true }))
end

--[[
//---- DESATIVADOS ----
Registro integral dos binds Mango; as versoes compativeis foram adaptadas acima.
Conflitos com amonetlol ficam inativos aqui: Q, Tab, W, equal, minus, C, T,
Return, D, E, H, Shift+L, M, Shift+P, X e workspaces numericos.
Sem equivalente/script disponivel: Y, Shift+equal/minus, Shift+T,
Shift+Return, Alt+H/L.

bind=SUPER,Q,killclient
bind=SUPER,Tab,toggleoverview
bind=SUPER,Space,togglefloating
bind=SUPER,W,spawn_shell,~/.config/mango/scripts/toggle-waybar.sh
bind=SUPER+SHIFT,Tab,spawn_shell,~/.config/mango/scripts/wallpaper-picker.sh
bind=SUPER,Y,toggleglobal,

bind=SUPER,equal,spawn_shell,~/.config/mango/scripts/volume-control.sh up
bind=SUPER,minus,spawn_shell,~/.config/mango/scripts/volume-control.sh down
bind=SUPER+SHIFT,equal,spawn_shell,~/.config/mango/scripts/ext-brightness-control.sh up
bind=SUPER+SHIFT,minus,spawn_shell,~/.config/mango/scripts/ext-brightness-control.sh down
bind=SUPER,C,spawn_shell,~/.config/mango/scripts/picker.sh

bind=SUPER,T,spawn,foot
bind=SUPER+SHIFT,T,spawn,st
bind=SUPER,Return,spawn,wl-kbptr
bind=SUPER+SHIFT,Return,spawn,wl-kbptr -o modes=tile,bisect

bind=SUPER,D,spawn,fuzzel
bind=SUPER,B,spawn,firefox-devedition
bind=SUPER,E,spawn,emacs
bind=SUPER,A,spawn,foot yazi
bind=SUPER+SHIFT,A,spawn,dolphin

bind=SUPER,1,view,1
bind=SUPER,2,view,2
bind=SUPER,3,view,3
bind=SUPER,4,view,4
bind=SUPER,5,view,5
bind=SUPER,6,view,6
bind=SUPER,7,view,7
bind=SUPER,8,view,8
bind=SUPER,9,view,9

bind=SUPER+SHIFT,1,tag,1
bind=SUPER+SHIFT,2,tag,2
bind=SUPER+SHIFT,3,tag,3
bind=SUPER+SHIFT,4,tag,4
bind=SUPER+SHIFT,5,tag,5
bind=SUPER+SHIFT,6,tag,6
bind=SUPER+SHIFT,7,tag,7
bind=SUPER+SHIFT,8,tag,8
bind=SUPER+SHIFT,9,tag,9

bind=SUPER,H,focusdir,left
bind=SUPER,L,focusdir,right
bind=SUPER,K,focusdir,up
bind=SUPER,J,focusdir,down

bind=ALT,Tab,focusstack,next
bind=ALT+SHIFT,Tab,focusstack,prev

bind=SUPER+SHIFT,H,exchange_client,left
bind=SUPER+SHIFT,L,exchange_client,right
bind=SUPER+SHIFT,K,exchange_client,up
bind=SUPER+SHIFT,J,exchange_client,down

bind=SUPER+ALT,H,switch_proportion_preset
bind=SUPER+ALT,L,switch_proportion_preset

bind=SUPER,M,togglemaximizescreen
bind=SUPER+SHIFT,M,togglefullscreen

bind=SUPER+SHIFT,P,spawn_shell,~/.config/mango/scripts/screenshot.sh region clipboard freeze
bind=SUPER+ALT,P,spawn_shell,~/.config/mango/scripts/screenshot.sh fullscreen both
bind=SUPER,P,spawn_shell,~/.config/mango/scripts/screenshot.sh fullscreen clipboard
bind=SUPER+CTRL,P,spawn_shell,mango --output-folder $HOME/Pictures/Screenshots/ -m window -z
bind=SUPER,X,spawn_shell,~/.config/mango/scripts/screw.sh fullscreen compress 3

mousebind=SUPER,btn_left,moveresize,curmove
mousebind=SUPER,btn_right,moveresize,curresize

bind=SUPER+CTRL+SHIFT,Up,movewin,+0,-50
bind=SUPER+CTRL+SHIFT,Down,movewin,+0,+50
bind=SUPER+CTRL+SHIFT,Left,movewin,-50,+0
bind=SUPER+CTRL+SHIFT,Right,movewin,+50,+0

bind=SUPER+CTRL+SHIFT,K,movewin,+0,-50
bind=SUPER+CTRL+SHIFT,J,movewin,+0,+50
bind=SUPER+CTRL+SHIFT,H,movewin,-50,+0
bind=SUPER+CTRL+SHIFT,L,movewin,+50,+0

bind=CTRL+SUPER,K,resizewin,+0,-10%
bind=CTRL+SUPER,J,resizewin,+0,+10%
bind=CTRL+SUPER,H,resizewin,-10%,+0
bind=CTRL+SUPER,L,resizewin,+10%,+0

]]
