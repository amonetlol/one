#pragma once

void registerHyprexpoConfigValues();
